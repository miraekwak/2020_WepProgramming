var quiz = document.getElementsByTagName("h1"); // 제목에 해당하는 element를 가져옴

// title을 클릭하면 퀴즈가 나타남
// 퀴즈는 간단한 문제들로 구성되어 여러개의 문제 중 한개를 랜덤으로 출제한다.
// 사용자가 입력한 퀴즈에 대한 답이 문제에 대한 답과 일치하는지 확인
// 답이 맞다면 웹페이지 title을 바꿀 수 있는 기회가 주어짐.
// 한글자에 대해 queue 또는 stack 구조의 삽입, 삭제가 가능함.
// 사용자는 퀴즈를 풀면서 웹페이지 title을 한글자씩 바꾸어 나가면서 본인만의 title을 만들어 낼 수 있음
quiz.addEventListener("click",function(){

});

//--------------------------------------

// api 사용을 위한 코드로 다음의 블로그를 가져와서 블로그 목록을 출력
$(document).ready(function(){
    //검색 버튼을 클릭하면 입력 값에 대한 검색을 시작함
        $("#search").click(function(){
        $.ajax({
            method: "GET",
            url: "https://dapi.kakao.com/v2/search/blog",

            data: { query: $("name").val()},
            headers: {Authorization: "KakaoAK 3940030f83e192ed5f3b3726b76aeed1"}
        })
        // 검색이 끝나면 서버로 부터 검색에 대한 결과를 받아와서 출력함
            .done(function(msg){
                $("p li").remove();
                console.log(msg);
                console.log(msg.documents);
                console.log(msg.documents.length);
                for(var i=0; i<msg.documents.length; i++){
                    $("p").append(`<li><a href="${msg.documents[i].url}"><strong>`+msg.documents[i].title+`</strong></a></li><br>`);
                }
            })
    });
});