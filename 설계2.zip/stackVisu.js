var div = document.getElementById("visuDiv"); // 시각화 표현될 div
var addBtn = document.getElementById("add");//삽입 버튼
var rmvBtn = document.getElementById("remove");// 삭제 버튼
var quiz = document.getElementsByTagName("h1"); // 제목에 해당하는 element를 가져옴

// title을 클릭하면 퀴즈가 나타남
// 퀴즈는 간단한 문제들로 구성되어 여러개의 문제 중 한개를 랜덤으로 출제한다.
// 사용자가 입력한 퀴즈에 대한 답이 문제에 대한 답과 일치하는지 확인
// 답이 맞다면 웹페이지 title을 바꿀 수 있는 기회가 주어짐.
// 한글자에 대해 queue 또는 stack 구조의 삽입, 삭제가 가능함.
// 사용자는 퀴즈를 풀면서 웹페이지 title을 한글자씩 바꾸어 나가면서 본인만의 title을 만들어 낼 수 있음
quiz.addEventListener("click",function(){

});

//--------------------------------------

// 삽입 버튼 클릭시 노드 역할을 하는 button을 생성한다.
// 처음 또는 마지막 삽입 버튼 클릭에 따라 맞는 위치에 노드를 연결한다.
// button을 통해 노드를 만들고 화살표 이미지로 노드 연결과정을 보여줌
firstAddBtn.addEventListener("click", function(){

});

// 입력받은 인덱스와 value에 대해 인덱스의 존재 여부, 올바른 value값인지 판단하는 함수
// 이 함수를 사용하여 버튼 클릭시 validation 진행
function is_exist(){
    
}

// 삭제 버튼 클릭시 노드 역할을 하는 버튼과 화살표 이미지를 삭제하여 시각적으로 노드가 삭제되었음을 보여주는 함수
// 입력받은 값에 대한 validation을 진행
// 값을 삭제할 때 stack구조에 맞게 맨뒤에서 선택한 버튼에 맞게 값을 삭제한다.
rmvBtn.addEventListener("click", function(){

});

// 이미 시각화된 노드의 값 변경을 원할 경우 해당 버튼을 클릭함
window.onclick = function(event){
    // event target이 버튼이면 해당 button의 값 변경을 위한 모달이 나타남
    // 모달을 통해 값을 입력받아 이미 시각화된 노드의 값을 변경
};