var quiz = document.getElementsByTagName("h1"); // 제목에 해당하는 element를 가져옴

// title을 클릭하면 퀴즈가 나타남
// 퀴즈는 간단한 문제들로 구성되어 여러개의 문제 중 한개를 랜덤으로 출제한다.
// 사용자가 입력한 퀴즈에 대한 답이 문제에 대한 답과 일치하는지 확인
// 답이 맞다면 웹페이지 title을 바꿀 수 있는 기회가 주어짐.
// 한글자에 대해 queue 또는 stack 구조의 삽입, 삭제가 가능함.
// 사용자는 퀴즈를 풀면서 웹페이지 title을 한글자씩 바꾸어 나가면서 본인만의 title을 만들어 낼 수 있음
quiz.addEventListener("click",function(){

});

